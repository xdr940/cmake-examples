#include <iostream>

#include "sublib1/sublib1.h"

void sublib1::print()
{
    std::cout << "Hello sub-library 1!" << std::endl;
}
