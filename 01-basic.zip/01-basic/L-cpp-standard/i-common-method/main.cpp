#include <iostream>

int main(int argc, char *argv[])
{
    auto message = "Hello C++11";
    std::cout << message << std::endl;
    return 0;
}
